package com.assignment4.microserviceswebinterface;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceswebinterfaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
