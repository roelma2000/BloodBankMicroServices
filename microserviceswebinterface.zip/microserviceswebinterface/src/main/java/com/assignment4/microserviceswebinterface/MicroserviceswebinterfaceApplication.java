package com.assignment4.microserviceswebinterface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceswebinterfaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceswebinterfaceApplication.class, args);
	}

}
